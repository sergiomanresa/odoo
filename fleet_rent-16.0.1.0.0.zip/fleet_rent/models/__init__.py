# See LICENSE file for full copyright and licensing details.

from . import fleet_rent_account
from . import fleet_res_partner
from . import fleet_rent
from . import fleet
