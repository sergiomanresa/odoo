=================
 Fleet Rent
=================

Vehicle Rental System will help to which helps in managing the rental of vehicles

========
Features
========

1- Vehicle Rental Management
2- Multiple Plans for Rental Contract(Days/Weeks/Months/Years)
3- Integrated with Accounting Module.
4- Manage Rental Payment History
5- Damage Checking Facility
6- Fleet Rental Report

============
Similar Apps
============
Fleet Rental Management
serpent Fleet Rental Vehicle apps
Online Fleet Rental
Complete Rental Solution for Fleet Rental
Rental CAR Business Solution
