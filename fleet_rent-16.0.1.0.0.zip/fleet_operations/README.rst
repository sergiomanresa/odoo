=================
 Fleet Operations
=================

Fleet management system will help to manage all vehicle-related operations including the repair and maintenance work and manage the vehicles.

========
Features
========

1- Vehicle Management
2- Vehicle Registration
3- Driver management
4- Vehicle repair and maintenance management
5- Vehicle Service Log
6- Semi-Automated Odometer Management
7- Keep History Of Fleet Vehicles
8- Write Off Vehicles From The Fleet
9- Analysis and Reporting

============
Similar Apps
============
Fleet Management extension
serpent fleet operations apps
Driver management
Multiple Branch Unit Operation for Fleet App
fleet management odoo apps

